package com.mcje.launcher

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import java.io.File

class UploadActivity : Activity() {

    private var videoFile: File? = null
    private var thumbnailUri: Uri? = null
    private val PICK_THUMBNAIL = 2001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload)

        val path = intent.getStringExtra("videoPath")
        if (path != null) videoFile = File(path)

        val etTitle = findViewById<EditText>(R.id.etTitle)
        val etDescription = findViewById<EditText>(R.id.etDescription)
        val etTags = findViewById<EditText>(R.id.etTags)
        val spPrivacy = findViewById<Spinner>(R.id.spPrivacy)
        val btnThumb = findViewById<Button>(R.id.btnPickThumbnail)
        val btnUpload = findViewById<Button>(R.id.btnUpload)

        btnThumb.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "image/*"
            startActivityForResult(intent, PICK_THUMBNAIL)
        }

        btnUpload.setOnClickListener {
            if (videoFile == null) return@setOnClickListener
            val title = etTitle.text.toString()
            val desc = etDescription.text.toString()
            val tags = etTags.text.toString().split(",").map { it.trim() }
            val privacy = spPrivacy.selectedItem.toString()

            Thread {
                val videoId = YouTubeUploader.uploadVideo(
                    videoFile!!, title, desc, tags, privacy,
                    thumbnailUri?.let { File(it.path!!) }
                )
                runOnUiThread {
                    if (videoId != null) Toast.makeText(this, "Uploaded! ID: $videoId", Toast.LENGTH_LONG).show()
                    else Toast.makeText(this, "Upload failed", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_THUMBNAIL && resultCode == RESULT_OK) {
            thumbnailUri = data?.data
            Toast.makeText(this, "Thumbnail selected", Toast.LENGTH_SHORT).show()
        }
    }
}