package com.mcje.launcher

import android.app.Activity
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.*

class SkinStudioActivity : Activity() {
    private lateinit var imageView: ImageView
    private lateinit var btnLoad: Button
    private lateinit var btnSave: Button
    private lateinit var btnImport: Button
    private lateinit var skinManager: SkinManager
    private lateinit var bitmap: Bitmap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skin_studio)

        imageView = findViewById(R.id.skinPreview)
        btnLoad = findViewById(R.id.btnLoadSkin)
        btnSave = findViewById(R.id.btnSaveSkin)
        btnImport = findViewById(R.id.btnImportSkin)
        skinManager = SkinManager(this)

        bitmap = Bitmap.createBitmap(64,64,Bitmap.Config.ARGB_8888)
        imageView.setImageBitmap(bitmap)

        btnLoad.setOnClickListener {
            val skin = skinManager.loadSkin("default")
            if(skin != null){
                bitmap = skin
                imageView.setImageBitmap(bitmap)
                Toast.makeText(this,"Skin loaded",Toast.LENGTH_SHORT).show()
            }
        }

        btnSave.setOnClickListener {
            skinManager.saveSkin("my_custom_skin", bitmap)
            Toast.makeText(this,"Skin saved!",Toast.LENGTH_SHORT).show()
        }

        btnImport.setOnClickListener {
            val imported = skinManager.importSkinFromGallery()
            if(imported != null){
                bitmap = imported
                imageView.setImageBitmap(bitmap)
                Toast.makeText(this,"Skin imported!",Toast.LENGTH_SHORT).show()
            }
        }
    }
}