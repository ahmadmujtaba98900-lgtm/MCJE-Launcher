package com.mcje.launcher

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnPlay = findViewById<Button>(R.id.btnPlay)
        val btnRecord = findViewById<Button>(R.id.btnRecord)
        val btnUpload = findViewById<Button>(R.id.btnUpload)
        val btnSkinStudio = findViewById<Button>(R.id.btnSkinStudio)

        btnPlay.setOnClickListener { startActivity(Intent(this, LauncherCore::class.java)) }
        btnRecord.setOnClickListener { startActivity(Intent(this, RecordActivity::class.java)) }
        btnUpload.setOnClickListener { startActivity(Intent(this, UploadActivity::class.java)) }
        btnSkinStudio.setOnClickListener { startActivity(Intent(this, SkinStudioActivity::class.java)) }
    }
}