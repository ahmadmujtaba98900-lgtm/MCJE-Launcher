package com.mcje.launcher

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class RecordActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this)
        text.text = "Recording feature placeholder"
        setContentView(text)
    }
}