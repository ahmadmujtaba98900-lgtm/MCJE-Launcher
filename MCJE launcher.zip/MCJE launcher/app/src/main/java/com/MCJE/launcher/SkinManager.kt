package com.mcje.launcher

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment
import android.content.Intent
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

class SkinManager(private val activity: Activity) {
    private val skinsFolder = File(Environment.getExternalStorageDirectory(), "games/MCJE_Launcher/skins")

    init { if(!skinsFolder.exists()) skinsFolder.mkdirs() }

    fun saveSkin(name: String, bitmap: Bitmap){
        val file = File(skinsFolder, "$name.png")
        val fos = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
        fos.flush()
        fos.close()
    }

    fun loadSkin(name: String): Bitmap? {
        val file = File(skinsFolder, "$name.png")
        if(file.exists()) return BitmapFactory.decodeFile(file.absolutePath)
        return null
    }

    fun importSkinFromGallery(): Bitmap? {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        activity.startActivityForResult(intent, 3001)
        return null
    }
}