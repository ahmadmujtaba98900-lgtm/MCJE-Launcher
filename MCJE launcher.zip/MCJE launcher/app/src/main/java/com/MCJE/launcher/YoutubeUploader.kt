package com.mcje.launcher

import android.util.Log
import com.google.api.client.http.FileContent
import com.google.api.services.youtube.YouTube
import com.google.api.services.youtube.model.Video
import com.google.api.services.youtube.model.VideoSnippet
import com.google.api.services.youtube.model.VideoStatus
import java.io.File
import java.util.*

object YouTubeUploader {
    var youtube: YouTube? = null

    fun uploadVideo(
        videoFile: File,
        title: String,
        description: String,
        tags: List<String>,
        privacy: String,
        thumbnailFile: File? = null
    ): String? {
        if (youtube == null) return null
        val snippet = VideoSnippet().apply { this.title = title; this.description = description; this.tags = tags }
        val status = VideoStatus().apply { this.privacyStatus = privacy.lowercase(Locale.getDefault()) }
        val videoObject = Video().apply { this.snippet = snippet; this.status = status }
        val mediaContent = FileContent("video/*", videoFile)
        val request = youtube!!.videos().insert("snippet,status", videoObject, mediaContent)
        val response = request.execute()
        if (thumbnailFile != null && thumbnailFile.exists()) youtube!!.thumbnails().set(response.id, FileContent("image/*", thumbnailFile)).execute()
        Log.i("YouTubeUploader", "Uploaded video ID: ${response.id}")
        return response.id
    }
}