package com.mcje.launcher

import android.app.Activity
import android.os.Bundle
import android.os.Environment
import android.widget.TextView
import java.io.File

class LauncherCore : Activity() {
    lateinit var mcjeFolder: File

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mcjeFolder = File(Environment.getExternalStorageDirectory(), "games/MCJE_Launcher")
        if (!mcjeFolder.exists()) mcjeFolder.mkdirs()

        val text = TextView(this)
        text.text = "MCJE Core Launcher\nFolder at:\n${mcjeFolder.path}"
        setContentView(text)
    }
}